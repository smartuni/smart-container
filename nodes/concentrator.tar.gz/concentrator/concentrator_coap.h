#ifndef CONCENTRATOR_COAP_H
#define CONCENTRATOR_COAP_H

#define MESSAGE_TYPE_HEARTBEAT 10

void server_init(void);

#endif
